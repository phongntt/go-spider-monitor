script
  // Function to run PL/SQL Statement (seperator by ;)
  function runStmt(strStmt) {
    sqlcl.setStmt(strStmt);
    sqlcl.run();
  }

  //----- MAIN -----

  var curDate = new Date();
  var localeCurDate = curDate.toLocaleString(); // for log to console
  
  ctx.write('\n\n\n------{{EBD_Output_Begin}}-----\n');
  ctx.write('------{{Runtime: ' + localeCurDate + '}}-----\n');

  runStmt(
    "var checknum number;"
  	//"var err_code varchar2(200);\n" +
  	//"var err_msg varchar2(400);"
  );
  runStmt("exec select 123456 into :checknum from dual;");
  
  // Get value of SQL variables
  var ctxVarMap = ctx.getVarMap();
  var checkNum = ctxVarMap.get('CHECKNUM').getValue();

  ctx.write('Error checkNum: ' + checkNum + '\n');

  // exit code = 0 is default
  var exit_code = '0';
  if (checkNum != 123456) {
    //Exit code = 1
    exit_code = '1';
  }

  ctx.write('------{{EBD_Output_End}}------\n\n\n');
  
  // Exit
  runStmt('exit ' + exit_code);
/